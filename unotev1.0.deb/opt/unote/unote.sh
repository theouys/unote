!#/bin/bash
cd ~/
python3 /opt/unote/unote.py $1


